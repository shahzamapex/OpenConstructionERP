import{a1 as a,d4 as i,i$ as s,dN as n,W as c,hT as l,cZ as d,e7 as p,fS as h,iJ as k,c6 as m,eb as y,dO as g,hd as u,c7 as f,ca as v,gm as M,i_ as b,hk as C,fc as S,bt as x,fh as F,cU as w,dg as P,d3 as B,cc as T,b7 as L,fT as H,ep as z,b8 as j,ek as q,fu as A,gP as R,df as D,eL as W,b0 as U,gz as Z,c0 as V,ap as N,bG as I,iS as E,hj as G,em as O,ej as K,aU as _,cJ as Q,cV as Y,bz as $,l as J,dw as X,d1 as ee,de as ae,c$ as te,fY as re,gS as oe,fQ as ie,aq as se,mZ as ne,at as ce,eo as le,c_ as de,cY as pe,dE as he,d5 as ke,gK as me,bq as ye,aD as ge,C as ue,cS as fe,c9 as ve,t as Me,as as be,fd as Ce,ie as Se,cE as xe,eC as Fe,fU as we,ed as Pe,gr as Be,bH as Te,fK as Le,ao as He,G as ze,e2 as je,bY as qe,a3 as Ae,dc as Re,an as De,hU as We,bD as Ue,bF as Ze,bA as Ve,h2 as Ne,$ as Ie,au as Ee,aW as Ge,e8 as Oe,fZ as Ke,dz as _e,M as Qe,m_ as Ye,e9 as $e,d2 as Je,c8 as Xe,bi as ea,aR as aa,ei as ta,ar as ra,T as oa,cB as ia,c1 as sa,aC as na,db as ca,m$ as la,cA as da,k as pa,aT as ha,f_ as ka,dq as ma,eK as ya,S as ga,i as ua,eH as fa,cT as va,b6 as Ma,R as ba,p as Ca,cF as Sa,e as xa,bp as Fa,bv as wa,dl as Pa,dm as Ba,mX as Ta,j as La,eq as Ha,cm as za,fi as ja}from"./index-ACXICuXA.js";import{H as qa}from"./hammer-Bh7QrcnD.js";import{C as Aa,F as Ra,S as Da,H as Wa,M as Ua}from"./signature-KWmdlMQq.js";import{B as Za}from"./building-Cb2vT2Rz.js";import{F as Va}from"./flame-DtY-I839.js";import{D as Na}from"./droplet-BXbEud9t.js";import{W as Ia,S as Ea}from"./wind-BwChx7Ov.js";import{R as Ga}from"./recycle-DB5jCx7-.js";import{M as Oa}from"./mountain-DcDYsc-P.js";import{T as Ka}from"./train-front-Jey-0upe.js";import{S as _a}from"./signpost-DcqP67Tn.js";import{F as Qa}from"./file-CpGBscaP.js";import{F as Ya}from"./files-Ci9zGn6i.js";import{F as $a}from"./file-stack-DA7KIhIS.js";import{F as Ja}from"./file-clock-DZPTX22W.js";import{F as Xa}from"./file-archive-ZFwQjJnv.js";import{F as et}from"./file-box-Q1Q_cMFd.js";import{F as at}from"./folder-Cz5u5bT2.js";import{F as tt}from"./folder-kanban-D9uyVuYD.js";import{F as rt}from"./folder-tree-BcY7wFPH.js";import{F as ot}from"./folder-archive-CwQte04g.js";import{L as it}from"./library-Cd7_-Xpg.js";import{N as st}from"./notebook-pen-7M7b8B-G.js";import{P as nt}from"./paperclip-BrQ8oj0y.js";import{P as ct}from"./printer-D1N0S8Mw.js";import{S as lt}from"./scan-CJ6tWcAF.js";import{Q as dt}from"./qr-code-Cm5_kaxh.js";import{S as pt}from"./sticky-note-JKJ-SGlE.js";import{C as ht}from"./credit-card-BOA7JdYi.js";import{R as kt}from"./receipt-text-0HoSlN7q.js";import{P as mt}from"./package-search-fSXn1gXb.js";import{T as yt}from"./tag-wwJZO8Ib.js";import{T as gt}from"./tags-Defd_k8N.js";import{C as ut}from"./chart-pie-CjseHNbM.js";import{T as ft}from"./trending-down-ClLhZp0Y.js";import{S as vt}from"./sigma-Ds_3yx66.js";import{S as Mt}from"./sheet-WgDLF1OK.js";import{L as bt}from"./layout-template-CDGCZGmY.js";import{L as Ct}from"./list-todo-BPSTzQyy.js";import{L as St}from"./list-tree-5QvSn-ZM.js";import{H as xt}from"./hourglass-WRtdRBIp.js";import{U as Ft}from"./user-check-XmJrGZVl.js";import{U as wt}from"./user-cog-BGBbHSrQ.js";import{A as Pt}from"./award-D0iHM9lu.js";import{B as Bt}from"./bell-ring-DWzOvAPE.js";import{S as Tt}from"./share-2-Dnzw3DRA.js";import{L as Lt}from"./link-DSf8-4TY.js";import{H as Ht}from"./heart-pulse-Bnrp2N9M.js";import{M as zt}from"./microscope-BvVBQf_N.js";import{F as jt}from"./flask-conical-Dn_5o7Kq.js";import{T as qt}from"./trophy-D67MWU5h.js";import{C as At}from"./cog-CBNC4eeG.js";import{S as Rt}from"./server-C-QF_lp_.js";import{B as Dt}from"./blocks-DftbY5K8.js";import{C as Wt}from"./cuboid-DwruL-ZO.js";import{S as Ut}from"./shapes-6JAbZb4w.js";import{S as Zt}from"./smartphone-GRuQI9ce.js";import{W as Vt}from"./webhook-C1qB4y1o.js";import{C as Nt}from"./cable-ClcVEsHJ.js";import{L as It}from"./life-buoy-BSpIzdv9.js";import"./vendor-react-CubDQ7e2.js";import"./vendor-query-C8Q3gDnG.js";import"./vendor-preload-ckwbz45p.js";import"./vendor-recharts-Dcekwekq.js";import"./vendor-flow-dK_Bi2Kn.js";import"./vendor-i18n-DEAuu1GM.js";import"./i18n-en-CtAk2orm.js";import"./vendor-dompurify-ChJSIbGG.js";import"./vendor-dnd-DQtKELN-.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Et=a("BadgeDollarSign",[["path",{d:"M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",key:"3c2336"}],["path",{d:"M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8",key:"1h4pet"}],["path",{d:"M12 18V6",key:"zqpxq5"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gt=a("BadgeEuro",[["path",{d:"M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",key:"3c2336"}],["path",{d:"M7 12h5",key:"gblrwe"}],["path",{d:"M15 9.4a4 4 0 1 0 0 5.2",key:"1makmb"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ot=a("BadgePercent",[["path",{d:"M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",key:"3c2336"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"M9 9h.01",key:"1q5me6"}],["path",{d:"M15 15h.01",key:"lqbp3k"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Kt=a("Barcode",[["path",{d:"M3 5v14",key:"1nt18q"}],["path",{d:"M8 5v14",key:"1ybrkv"}],["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"M17 5v14",key:"ycjyhj"}],["path",{d:"M21 5v14",key:"nzette"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _t=a("BookMarked",[["path",{d:"M10 2v8l3-3 3 3V2",key:"sqw3rj"}],["path",{d:"M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",key:"k3hazp"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qt=a("BrickWall",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M12 9v6",key:"199k2o"}],["path",{d:"M16 15v6",key:"8rj2es"}],["path",{d:"M16 3v6",key:"1j6rpj"}],["path",{d:"M3 15h18",key:"5xshup"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M8 15v6",key:"1stoo3"}],["path",{d:"M8 3v6",key:"vlvjmk"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yt=a("Brush",[["path",{d:"m9.06 11.9 8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08",key:"1styjt"}],["path",{d:"M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z",key:"z0l1mu"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $t=a("CalendarCog",[["path",{d:"m15.2 16.9-.9-.4",key:"1r0w5f"}],["path",{d:"m15.2 19.1-.9.4",key:"j188fs"}],["path",{d:"M16 2v4",key:"4m81vk"}],["path",{d:"m16.9 15.2-.4-.9",key:"699xu"}],["path",{d:"m16.9 20.8-.4.9",key:"dfjc4z"}],["path",{d:"m19.5 14.3-.4.9",key:"1eb35c"}],["path",{d:"m19.5 21.7-.4-.9",key:"1tonu5"}],["path",{d:"M21 10.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6",key:"11kmuh"}],["path",{d:"m21.7 16.5-.9.4",key:"1knoei"}],["path",{d:"m21.7 19.5-.9-.4",key:"q4dx6b"}],["path",{d:"M3 10h18",key:"8toen8"}],["path",{d:"M8 2v4",key:"1cmpym"}],["circle",{cx:"18",cy:"18",r:"3",key:"1xkwt0"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jt=a("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xt=a("Contact",[["path",{d:"M16 2v2",key:"scm5qe"}],["path",{d:"M7 22v-2a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v2",key:"1waht3"}],["path",{d:"M8 2v2",key:"pbkmx"}],["circle",{cx:"12",cy:"11",r:"3",key:"itu57m"}],["rect",{x:"3",y:"4",width:"18",height:"18",rx:"2",key:"12vinp"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const er=a("Drill",[["path",{d:"M10 18a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H5a3 3 0 0 1-3-3 1 1 0 0 1 1-1z",key:"ioqxb1"}],["path",{d:"M13 10H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1l-.81 3.242a1 1 0 0 1-.97.758H8",key:"1rs59n"}],["path",{d:"M14 4h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-3",key:"105ega"}],["path",{d:"M18 6h4",key:"66u95g"}],["path",{d:"m5 10-2 8",key:"xt2lic"}],["path",{d:"m7 18 2-8",key:"1bzku2"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ar=a("Fan",[["path",{d:"M10.827 16.379a6.082 6.082 0 0 1-8.618-7.002l5.412 1.45a6.082 6.082 0 0 1 7.002-8.618l-1.45 5.412a6.082 6.082 0 0 1 8.618 7.002l-5.412-1.45a6.082 6.082 0 0 1-7.002 8.618l1.45-5.412Z",key:"484a7f"}],["path",{d:"M12 12v.01",key:"u5ubse"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const tr=a("Fence",[["path",{d:"M4 3 2 5v15c0 .6.4 1 1 1h2c.6 0 1-.4 1-1V5Z",key:"1n2rgs"}],["path",{d:"M6 8h4",key:"utf9t1"}],["path",{d:"M6 18h4",key:"12yh4b"}],["path",{d:"m12 3-2 2v15c0 .6.4 1 1 1h2c.6 0 1-.4 1-1V5Z",key:"3ha7mj"}],["path",{d:"M14 8h4",key:"1r8wg2"}],["path",{d:"M14 18h4",key:"1t3kbu"}],["path",{d:"m20 3-2 2v15c0 .6.4 1 1 1h2c.6 0 1-.4 1-1V5Z",key:"dfd4e2"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rr=a("FireExtinguisher",[["path",{d:"M15 6.5V3a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v3.5",key:"sqyvz"}],["path",{d:"M9 18h8",key:"i7pszb"}],["path",{d:"M18 3h-3",key:"7idoqj"}],["path",{d:"M11 3a6 6 0 0 0-6 6v11",key:"1v5je3"}],["path",{d:"M5 13h4",key:"svpcxo"}],["path",{d:"M17 10a4 4 0 0 0-8 0v10a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2Z",key:"vsjego"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const or=a("Forklift",[["path",{d:"M12 12H5a2 2 0 0 0-2 2v5",key:"7zsz91"}],["circle",{cx:"13",cy:"19",r:"2",key:"wjnkru"}],["circle",{cx:"5",cy:"19",r:"2",key:"v8kfzx"}],["path",{d:"M8 19h3m5-17v17h6M6 12V7c0-1.1.9-2 2-2h3l5 5",key:"13bk1p"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ir=a("Fuel",[["line",{x1:"3",x2:"15",y1:"22",y2:"22",key:"xegly4"}],["line",{x1:"4",x2:"14",y1:"9",y2:"9",key:"xcnuvu"}],["path",{d:"M14 22V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v18",key:"16j0yd"}],["path",{d:"M14 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 2 2a2 2 0 0 0 2-2V9.83a2 2 0 0 0-.59-1.42L18 5",key:"7cu91f"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const sr=a("HousePlus",[["path",{d:"M13.22 2.416a2 2 0 0 0-2.511.057l-7 5.999A2 2 0 0 0 3 10v9a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7.354",key:"5phn05"}],["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M15 6h6",key:"1jlkvy"}],["path",{d:"M18 3v6",key:"x1uolp"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nr=a("IdCard",[["path",{d:"M16 10h2",key:"8sgtl7"}],["path",{d:"M16 14h2",key:"epxaof"}],["path",{d:"M6.17 15a3 3 0 0 1 5.66 0",key:"n6f512"}],["circle",{cx:"9",cy:"11",r:"2",key:"yxgjnd"}],["rect",{x:"2",y:"5",width:"20",height:"14",rx:"2",key:"qneu4z"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const cr=a("Images",[["path",{d:"M18 22H4a2 2 0 0 1-2-2V6",key:"pblm9e"}],["path",{d:"m22 13-1.296-1.296a2.41 2.41 0 0 0-3.408 0L11 18",key:"nf6bnh"}],["circle",{cx:"12",cy:"8",r:"2",key:"1822b1"}],["rect",{width:"16",height:"16",x:"6",y:"2",rx:"2",key:"12espp"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const lr=a("Kanban",[["path",{d:"M6 5v11",key:"mdvv1e"}],["path",{d:"M12 5v6",key:"14ar3b"}],["path",{d:"M18 5v14",key:"7ji314"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const dr=a("Navigation",[["polygon",{points:"3 11 22 2 13 21 11 13 3 11",key:"1ltx0t"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pr=a("Notebook",[["path",{d:"M2 6h4",key:"aawbzj"}],["path",{d:"M2 10h4",key:"l0bgd4"}],["path",{d:"M2 14h4",key:"1gsvsf"}],["path",{d:"M2 18h4",key:"1bu2t1"}],["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",key:"1nb95v"}],["path",{d:"M16 2v20",key:"rotuqe"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const hr=a("PaintBucket",[["path",{d:"m19 11-8-8-8.6 8.6a2 2 0 0 0 0 2.8l5.2 5.2c.8.8 2 .8 2.8 0L19 11Z",key:"irua1i"}],["path",{d:"m5 2 5 5",key:"1lls2c"}],["path",{d:"M2 13h15",key:"1hkzvu"}],["path",{d:"M22 20a2 2 0 1 1-4 0c0-1.6 1.7-2.4 2-4 .3 1.6 2 2.4 2 4Z",key:"xk76lq"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const kr=a("PaintRoller",[["rect",{width:"16",height:"6",x:"2",y:"2",rx:"2",key:"jcyz7m"}],["path",{d:"M10 16v-2a2 2 0 0 1 2-2h8a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2",key:"1b9h7c"}],["rect",{width:"4",height:"6",x:"8",y:"16",rx:"1",key:"d6e7yl"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const mr=a("PersonStanding",[["circle",{cx:"12",cy:"5",r:"1",key:"gxeob9"}],["path",{d:"m9 20 3-6 3 6",key:"se2kox"}],["path",{d:"m6 8 6 2 6-2",key:"4o3us4"}],["path",{d:"M12 10v4",key:"1kjpxc"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yr=a("Pickaxe",[["path",{d:"M14.531 12.469 6.619 20.38a1 1 0 1 1-3-3l7.912-7.912",key:"we99rg"}],["path",{d:"M15.686 4.314A12.5 12.5 0 0 0 5.461 2.958 1 1 0 0 0 5.58 4.71a22 22 0 0 1 6.318 3.393",key:"1w6hck"}],["path",{d:"M17.7 3.7a1 1 0 0 0-1.4 0l-4.6 4.6a1 1 0 0 0 0 1.4l2.6 2.6a1 1 0 0 0 1.4 0l4.6-4.6a1 1 0 0 0 0-1.4z",key:"15hgfx"}],["path",{d:"M19.686 8.314a12.501 12.501 0 0 1 1.356 10.225 1 1 0 0 1-1.751-.119 22 22 0 0 0-3.393-6.319",key:"452b4h"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const gr=a("PlugZap",[["path",{d:"M6.3 20.3a2.4 2.4 0 0 0 3.4 0L12 18l-6-6-2.3 2.3a2.4 2.4 0 0 0 0 3.4Z",key:"goz73y"}],["path",{d:"m2 22 3-3",key:"19mgm9"}],["path",{d:"M7.5 13.5 10 11",key:"7xgeeb"}],["path",{d:"M10.5 16.5 13 14",key:"10btkg"}],["path",{d:"m18 3-4 4h6l-4 4",key:"16psg9"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ur=a("Scaling",[["path",{d:"M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",key:"1m0v6g"}],["path",{d:"M14 15H9v-5",key:"pi4jk9"}],["path",{d:"M16 3h5v5",key:"1806ms"}],["path",{d:"M21 3 9 15",key:"15kdhq"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fr=a("Shovel",[["path",{d:"M2 22v-5l5-5 5 5-5 5z",key:"1fh25c"}],["path",{d:"M9.5 14.5 16 8",key:"1smz5x"}],["path",{d:"m17 2 5 5-.5.5a3.53 3.53 0 0 1-5 0s0 0 0 0a3.53 3.53 0 0 1 0-5L17 2",key:"1q8uv5"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const vr=a("Siren",[["path",{d:"M7 18v-6a5 5 0 1 1 10 0v6",key:"pcx96s"}],["path",{d:"M5 21a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-1a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2z",key:"1b4s83"}],["path",{d:"M21 12h1",key:"jtio3y"}],["path",{d:"M18.5 4.5 18 5",key:"g5sp9y"}],["path",{d:"M2 12h1",key:"1uaihz"}],["path",{d:"M12 2v1",key:"11qlp1"}],["path",{d:"m4.929 4.929.707.707",key:"1i51kw"}],["path",{d:"M12 12v6",key:"3ahymv"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Mr=a("Store",[["path",{d:"m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7",key:"ztvudi"}],["path",{d:"M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8",key:"1b2hhj"}],["path",{d:"M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4",key:"2ebpfo"}],["path",{d:"M2 7h20",key:"1fcdvo"}],["path",{d:"M22 7v3a2 2 0 0 1-2 2a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 16 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 12 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 8 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 4 12a2 2 0 0 1-2-2V7",key:"6c3vgh"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const br=a("Tablet",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",ry:"2",key:"76otgf"}],["line",{x1:"12",x2:"12.01",y1:"18",y2:"18",key:"1dp563"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Cr=a("TrafficCone",[["path",{d:"M9.3 6.2a4.55 4.55 0 0 0 5.4 0",key:"flyxqv"}],["path",{d:"M7.9 10.7c.9.8 2.4 1.3 4.1 1.3s3.2-.5 4.1-1.3",key:"1nlxxg"}],["path",{d:"M13.9 3.5a1.93 1.93 0 0 0-3.8-.1l-3 10c-.1.2-.1.4-.1.6 0 1.7 2.2 3 5 3s5-1.3 5-3c0-.2 0-.4-.1-.5Z",key:"vz7x1l"}],["path",{d:"m7.5 12.2-4.7 2.7c-.5.3-.8.7-.8 1.1s.3.8.8 1.1l7.6 4.5c.9.5 2.1.5 3 0l7.6-4.5c.7-.3 1-.7 1-1.1s-.3-.8-.8-1.1l-4.7-2.8",key:"1xfzlw"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Sr=a("TreePine",[["path",{d:"m17 14 3 3.3a1 1 0 0 1-.7 1.7H4.7a1 1 0 0 1-.7-1.7L7 14h-.3a1 1 0 0 1-.7-1.7L9 9h-.2A1 1 0 0 1 8 7.3L12 3l4 4.3a1 1 0 0 1-.8 1.7H15l3 3.3a1 1 0 0 1-.7 1.7H17Z",key:"cpyugq"}],["path",{d:"M12 22v-3",key:"kmzjlo"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xr=a("Trees",[["path",{d:"M10 10v.2A3 3 0 0 1 8.9 16H5a3 3 0 0 1-1-5.8V10a3 3 0 0 1 6 0Z",key:"1l6gj6"}],["path",{d:"M7 16v6",key:"1a82de"}],["path",{d:"M13 19v3",key:"13sx9i"}],["path",{d:"M12 19h8.3a1 1 0 0 0 .7-1.7L18 14h.3a1 1 0 0 0 .7-1.7L16 9h.2a1 1 0 0 0 .8-1.7L13 3l-1.4 1.5",key:"1sj9kv"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Fr=a("Video",[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wr=a("Waves",[["path",{d:"M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"knzxuh"}],["path",{d:"M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"2jd2cc"}],["path",{d:"M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"rd2r6e"}]]),e=(r,t,o)=>({name:r,icon:t,keywords:o}),Pr=[{id:"construction",icons:[e("HardHat",i,"helmet safety site worker"),e("Construction",s,"barrier roadworks works"),e("TrafficCone",Cr,"cone site road"),e("Hammer",qa,"tool build carpentry"),e("Wrench",n,"tool repair maintenance"),e("Drill",er,"tool power"),e("Shovel",fr,"dig earthworks excavation"),e("Pickaxe",yr,"dig mining excavation"),e("PaintRoller",kr,"paint finish decoration"),e("PaintBucket",hr,"paint fill colour"),e("Brush",Yt,"paint clean"),e("Ruler",c,"measure length takeoff"),e("PencilRuler",l,"design drawing measure"),e("DraftingCompass",d,"design geometry drawing"),e("Scaling",ur,"scale resize"),e("Forklift",or,"lift logistics machine"),e("Truck",p,"delivery transport logistics"),e("Container",Aa,"shipping storage"),e("BrickWall",Qt,"masonry wall bricks"),e("Fence",tr,"boundary site"),e("Warehouse",h,"storage depot yard"),e("Factory",k,"prefab plant manufacturing"),e("Building",Za,"office tower property"),e("Building2",m,"company office tower"),e("Store",Mr,"shop retail"),e("Landmark",y,"public civic bank"),e("House",g,"home residential"),e("HousePlus",sr,"new home residential"),e("Fuel",ir,"diesel petrol plant"),e("Plug",u,"power electrical"),e("PlugZap",gr,"electrical power"),e("Zap",f,"electric energy power"),e("Lightbulb",v,"idea lighting electrical"),e("Flame",Va,"fire hot work"),e("Droplets",M,"water plumbing"),e("Droplet",Na,"water liquid"),e("Thermometer",b,"temperature hvac"),e("Wind",Ia,"ventilation air hvac"),e("Fan",ar,"hvac air ventilation"),e("Sun",C,"solar daylight"),e("Leaf",S,"green sustainability esg"),e("TreePine",Sr,"landscape nature"),e("Trees",xr,"landscape green"),e("Recycle",Ga,"waste circular"),e("Trash2",x,"waste delete"),e("Mountain",Oa,"terrain earthworks"),e("Waves",wr,"water marine"),e("TrainFront",Ka,"rail transport"),e("Route",F,"road route path"),e("Signpost",_a,"direction wayfinding"),e("MapPin",w,"location site place"),e("Map",P,"map plan site"),e("Navigation",dr,"direction gps"),e("Compass",B,"navigate explore"),e("Globe2",T,"world regional")]},{id:"documents",icons:[e("FileText",L,"document file text"),e("File",Qa,"document file"),e("Files",Ya,"documents files"),e("FileStack",$a,"documents stack"),e("FileCheck",H,"approved document"),e("FileSignature",z,"signature contract sign"),e("FileSpreadsheet",j,"spreadsheet excel table"),e("FileBarChart",q,"report chart"),e("FileClock",Ja,"pending document history"),e("FileSearch",A,"search document"),e("FileWarning",R,"document issue"),e("FilePen",D,"edit document"),e("FileArchive",Xa,"archive zip"),e("FileBox",et,"package document"),e("FileInput",W,"import document"),e("FileOutput",Ra,"export document"),e("Folder",at,"folder files"),e("FolderOpen",U,"folder project"),e("FolderKanban",tt,"folder board"),e("FolderTree",rt,"hierarchy folder"),e("FolderArchive",ot,"archive folder"),e("Archive",Z,"archive box records"),e("BookOpen",V,"manual guide reading"),e("BookMarked",_t,"bookmark manual"),e("Library",it,"library catalogue"),e("Notebook",pr,"notes diary"),e("NotebookPen",st,"diary log notes"),e("ClipboardList",N,"checklist forms"),e("ClipboardCheck",I,"inspection checklist done"),e("ClipboardPen",E,"form edit"),e("Paperclip",nt,"attachment"),e("Printer",ct,"print"),e("Scan",lt,"scan capture"),e("ScanLine",G,"scan barcode"),e("QrCode",dt,"qr code tag"),e("Barcode",Kt,"barcode inventory"),e("Stamp",O,"approval stamp seal"),e("Signature",Da,"sign contract"),e("PenTool",K,"draw design markup"),e("Pencil",_,"edit write"),e("StickyNote",pt,"note memo"),e("Mail",Q,"email letter"),e("Inbox",Y,"inbox incoming"),e("Send",$,"send transmit")]},{id:"money",icons:[e("Calculator",J,"estimate calculate cost"),e("Coins",X,"money cost"),e("Banknote",ee,"cash money payment"),e("Wallet",ae,"budget wallet money"),e("CreditCard",ht,"payment card"),e("Receipt",te,"invoice receipt bill"),e("ReceiptText",kt,"invoice bill"),e("PiggyBank",re,"savings budget"),e("HandCoins",oe,"payment funding"),e("BadgeDollarSign",Et,"price cost"),e("BadgeEuro",Gt,"euro price"),e("BadgePercent",Ot,"discount markup percent"),e("Percent",ie,"percent rate markup"),e("DollarSign",se,"dollar money"),e("Euro",ne,"euro money"),e("Scale",ce,"balance contract legal compare"),e("Gavel",le,"legal claim dispute"),e("Handshake",de,"deal agreement partner"),e("ShoppingCart",pe,"purchase procurement order"),e("Package",he,"package material module"),e("PackageCheck",ke,"delivered received"),e("PackageOpen",me,"unpacked material"),e("PackageSearch",mt,"find material"),e("Boxes",ye,"inventory materials stock modules"),e("Box",ge,"item material 3d"),e("Tag",yt,"tag price label"),e("Tags",gt,"tags labels")]},{id:"charts",icons:[e("BarChart3",ue,"chart report analytics"),e("LineChart",fe,"trend chart"),e("PieChart",ut,"share chart"),e("TrendingUp",ve,"growth trend up"),e("TrendingDown",ft,"decline trend down"),e("Activity",Me,"activity pulse"),e("Gauge",be,"dashboard speed kpi"),e("Target",Ce,"goal target kpi"),e("Sigma",vt,"sum total"),e("Table",Se,"table grid"),e("Table2",xe,"table grid boq"),e("Sheet",Mt,"sheet spreadsheet"),e("LayoutGrid",Fe,"grid modules"),e("LayoutDashboard",we,"dashboard overview"),e("LayoutTemplate",bt,"template layout"),e("Kanban",lr,"board tasks"),e("ListChecks",Pe,"checklist tasks"),e("ListTodo",Ct,"todo tasks"),e("List",Be,"list items"),e("ListTree",St,"tree hierarchy wbs"),e("Network",Te,"network structure"),e("Workflow",Le,"workflow process"),e("GitBranch",He,"branch version pipeline"),e("GitCompare",ze,"compare diff"),e("Filter",je,"filter"),e("SlidersHorizontal",qe,"settings adjust"),e("Layers",Ae,"layers stack model")]},{id:"time",icons:[e("Calendar",Re,"calendar date"),e("CalendarDays",De,"schedule calendar"),e("CalendarCheck",We,"planned done"),e("CalendarClock",Ue,"deadline schedule"),e("CalendarRange",Ze,"period range"),e("CalendarCog",$t,"schedule settings"),e("Clock",Ve,"time hours"),e("Timer",Ne,"timer duration"),e("Hourglass",xt,"waiting duration"),e("History",Ie,"history log")]},{id:"people",icons:[e("Users",Ee,"team people"),e("User",Ge,"person user"),e("UserCheck",Ft,"approved person"),e("UserPlus",Oe,"add person invite"),e("UserCog",wt,"user settings"),e("Contact",Xt,"contact person"),e("IdCard",nr,"identity badge"),e("BadgeCheck",Ke,"verified certified"),e("Award",Pt,"award certificate"),e("GraduationCap",_e,"training learning"),e("PersonStanding",mr,"person safety"),e("HeartHandshake",Wa,"care partnership"),e("MessageSquare",Qe,"chat message comment"),e("MessagesSquare",Ye,"discussion"),e("Phone",$e,"call phone"),e("Video",Fr,"video meeting"),e("Megaphone",Je,"announcement"),e("Bell",Xe,"notification alert"),e("BellRing",Bt,"alert ringing"),e("Share2",Tt,"share"),e("Link",Lt,"link url"),e("Link2",ea,"link connect")]},{id:"quality",icons:[e("ShieldCheck",aa,"safety quality approved"),e("Shield",ta,"safety protection"),e("ShieldAlert",ra,"risk safety alert"),e("AlertTriangle",oa,"warning hazard risk"),e("AlertCircle",ia,"alert issue"),e("AlertOctagon",sa,"stop critical"),e("CircleCheck",na,"done ok"),e("CheckSquare",ca,"checked task"),e("Bug",la,"defect bug"),e("Siren",vr,"emergency"),e("FireExtinguisher",rr,"fire safety"),e("HeartPulse",Ht,"health safety"),e("Eye",da,"inspection view"),e("Search",pa,"search find"),e("ScanSearch",Ea,"inspect search"),e("Microscope",zt,"test lab"),e("FlaskConical",jt,"lab test material"),e("Lock",ha,"lock security"),e("KeyRound",ka,"key access"),e("Flag",ma,"milestone flag"),e("Milestone",Ua,"milestone"),e("Trophy",qt,"achievement"),e("Star",ya,"favourite star")]},{id:"tech",icons:[e("Settings",ga,"settings"),e("Cog",At,"settings gear"),e("Server",Rt,"server"),e("Database",ua,"database data"),e("HardDrive",fa,"storage drive"),e("Upload",va,"upload"),e("Download",Ma,"download"),e("RefreshCw",ba,"sync refresh"),e("Code",Jt,"code developer"),e("Bot",Ca,"bot ai agent"),e("BrainCircuit",Sa,"ai brain"),e("Sparkles",xa,"ai magic"),e("Wand2",Fa,"ai magic wand"),e("Puzzle",wa,"module plugin"),e("Blocks",Dt,"blocks modules"),e("Cuboid",Wt,"3d bim model"),e("Shapes",Ut,"shapes"),e("Camera",Pa,"photo camera"),e("Image",Ba,"image photo"),e("Images",cr,"gallery photos"),e("Monitor",Ta,"screen desktop"),e("Smartphone",Zt,"mobile phone"),e("Tablet",br,"tablet field"),e("Webhook",Vt,"integration webhook"),e("Cable",Nt,"integration connect"),e("Info",La,"info"),e("HelpCircle",Ha,"help question"),e("LifeBuoy",It,"support help"),e("Rocket",za,"launch start"),e("Bookmark",ja,"bookmark")]}],I1=Object.fromEntries(Pr.flatMap(r=>r.icons.map(t=>[t.name,t.icon])));export{I1 as MENU_ICON_BY_NAME,Pr as MENU_ICON_GROUPS};
